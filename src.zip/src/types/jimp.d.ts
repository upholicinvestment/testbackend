declare module "jimp" {
  const Jimp: any;
  export default Jimp;
}
